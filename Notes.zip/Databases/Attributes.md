The data about [[Entities]] that we store (username, password)

They are represented as columns in the database table.


