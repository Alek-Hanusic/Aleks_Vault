1 thing in each column

`Caleb Daniel Curry`

*Incorrect*

| Name    |     |
| --- | --- |
|Caleb Daniel Curry|     |


**Correct**

| Name  | Mid Name | Last Name |
| ------ | ------ | ----- |
| Caleb | Daniel  | Curry      |