### Structured Query Language

- used to **define** ([[DDL]]) database structure 
- used to **manipulate** ([[DML]]) data within database structure (INSERT,SEARCH,DELETE...)