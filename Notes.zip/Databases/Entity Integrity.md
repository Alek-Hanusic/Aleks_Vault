Entity integrity is concerned with **ensuring that each row of a table has a unique and non-null primary key value**

Example: ID