Ways to separate information/data over multiple tables

- Conceptual schema (basic requirements of database, no limits)
- Logical schema (how approximately the database should be structured)
- Physical schema (exact design of database)

Related: [[Data Integrity]]