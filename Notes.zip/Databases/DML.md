The [[SQL]] commands that deal with the manipulation of data present in the database belong to DML or Data Manipulation Language and this includes most of the [[SQL]] statements.

Ex: `UPDATE`
