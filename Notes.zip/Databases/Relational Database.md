Consists of [[Attributes]] and [[Entities]]



