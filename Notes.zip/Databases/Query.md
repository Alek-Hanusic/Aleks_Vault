A database query is used  to retrieve information from and take action on databases.
Primarily, queries are used to find specific data by filtering explicit criteria.

A database query is either an action query or a select query. A select query is one that retrieves data from a database. An action query asks for additional operations on data, such as insertion, updating, deleting or other forms of data manipulation.


