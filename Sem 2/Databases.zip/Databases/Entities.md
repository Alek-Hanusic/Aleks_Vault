The things we store data about (Person, Product, Customer)

==Multiple entities form [[Relationships]]==
