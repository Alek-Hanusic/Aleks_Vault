The software used to store, manage, [[Query]], and retrieve data stored in a [[Relational Database]].

It also enables [[Views]]

