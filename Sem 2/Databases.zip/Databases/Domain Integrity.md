Domain integrity is **the collection of processes that ensure the accuracy of each piece of data in a domain**. In this context, a domain is a set of acceptable values that a column is allowed to contain.

Example: "cake" in 10 digit phone number column
