## Sequences & Series
> A sequence is a LIST

> A series is a SUM

![[Pasted image 20230916153222.png]]
# Formulas

![[Pasted image 20230916182951.png]]

![[Seq & Series Cheat Sheet.png]]


