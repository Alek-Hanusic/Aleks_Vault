_DDL_ is a set of [[SQL]] commands used to create, modify, and delete database structures but not data.

Ex: `CREATE`
