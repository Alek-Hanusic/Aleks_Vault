Referential integrity is **a constraint on the database design that makes certain that each foreign key in a table point to a unique primary key value in another table**.
